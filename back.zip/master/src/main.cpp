#include <Arduino.h>
#include "settings.h"
#include <WiFi.h>
WiFiClient     client;
QueueHandle_t  buff;
QueueHandle_t  onBeat;


void serial1_callback()
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    char data = ' ';
    while(Serial1.available())
    {
        data = Serial1.read();
        xQueueSendToBackFromISR(buff, &data, &xHigherPriorityTaskWoken);
    }
}


static void wifi_task(void* parameter)
{
    char       single_data;
    BaseType_t isReadSuccess;

    while(1)
    {
        // Step1：尝试连接移动端，只有连接上以后，才会进入Step2
        Serial.println("Linking mobile terminal ...");
        delay(100);
        while (!client.connect(SERVER_IP, WIFI_PORT))
        {
            Serial.println("Linking mobile terminal ...");
            delay(100);
        }
        Serial.println("Success!");
        xQueueReset(buff);
        xQueueOverwrite(onBeat, &(ON_CONNECT));

        
        while (client.connected())
        {
            // Step2：从队列中获取数据
            isReadSuccess = xQueueReceive(buff, &single_data, 100);
            
            // Step3：发送数据
            if (isReadSuccess==pdPASS)
            {
                try{
                    client.write(&single_data, 1);
                }catch(...)
                {
                    Serial.println("Linking restart ...");
                } 
            }

            // Step4：检测心跳
            while (client.available())
            {
                client.read();
                xQueueOverwrite(onBeat, &(ON_CONNECT));
            }
        }
    }
}


static void loss_tcp(void* parameter)
{
    uint32_t state;
    while(1)
    {
        xQueuePeek(onBeat, &state, 0);
        while (state==NOT_BEGIN) {
            xQueueOverwrite(onBeat, &(NOT_BEGIN));
            vTaskDelay(2000);
            xQueuePeek(onBeat, &state, 0);
        }
        xQueueOverwrite(onBeat, &(LOSS_CONNECT));
        vTaskDelay(4000);
        xQueuePeek(onBeat, &state, 0);
        if (state==LOSS_CONNECT)
        {
            Serial.println("Loss TCP!");
            WiFi.disconnect();
            vTaskDelay(1000);
            ESP.restart();
        }
    }
}


void setup() {

    // 打开调试串口
    Serial.begin(115200);

    // 开启wifi
    WiFi.mode(WIFI_AP); 
	WiFi.softAPConfig(CLIENT_IP, AP_GATEWAY, AP_SUBNET);
    WiFi.softAP(WIFI_SSID, WIFI_PASSWORD);
    delay(500);
    Serial.println("Wifi Started success !");
    Serial.print("WiFi connected with IP:");
    Serial.println(WiFi.softAPIP());

    // 建立数据缓冲区
    buff = xQueueCreate(4096, sizeof(char));
    xQueueReset(buff);

    // 建立心跳
    onBeat = xQueueCreate(1, sizeof(uint32_t) );
    xQueueReset(onBeat);
    xQueueOverwrite(onBeat, &(NOT_BEGIN));

    // 打开通讯串口
    Serial1.begin(BAUDRATE, SERIAL_8N1, 22, 23);
    Serial1.onReceive(serial1_callback);

    // 开始Wifi任务
    xTaskCreatePinnedToCore(
        wifi_task,
        "wifi_task",
        10000,
        NULL,
        1,
        NULL,
        1
    );

    // 丢失tcp则重启
    xTaskCreatePinnedToCore(
        loss_tcp,
        "loss_tcp",
        1024,
        NULL,
        4,
        NULL,
        0
    );    
}

void loop()
{
    ;
}





